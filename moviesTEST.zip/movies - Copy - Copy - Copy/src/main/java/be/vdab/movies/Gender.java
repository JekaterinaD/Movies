package be.vdab.movies;

public enum Gender {
    M, F;
}
